CS628A Assignent 1
Implementing a version of Secure Cloud Storage